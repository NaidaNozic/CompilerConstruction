package at.tugraz.ist.cc;

public enum Type {
    STRING,
    INT,
    REF,
    NONE
}
