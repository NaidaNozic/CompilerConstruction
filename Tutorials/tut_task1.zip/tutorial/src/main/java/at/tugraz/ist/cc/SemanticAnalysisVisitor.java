package at.tugraz.ist.cc;

import java.util.ArrayList;
import java.util.List;

public class SemanticAnalysisVisitor extends TutorialBaseVisitor<Type> {
    List<String> objectIds = new ArrayList<>();

    @Override
    public Type visitReferenceDeclaration(TutorialParser.ReferenceDeclarationContext ctx) {
        this.objectIds.add(ctx.ID().getText());
        return Type.NONE;
    }

    @Override
    public Type visitINT(TutorialParser.INTContext ctx) {
        return Type.INT;
    }

    @Override
    public Type visitSTRING(TutorialParser.STRINGContext ctx) {
        return Type.STRING;
    }

    @Override
    public Type visitAdd(TutorialParser.AddContext ctx) {
        Type leftType = visit(ctx.operation(0));
        Type rightType = visit(ctx.operation(1));

        if (leftType != rightType) {
            System.out.println("Add operation was used on different types!");
            return Type.NONE;
        }

        switch (leftType) {
            case REF -> {
                System.out.println("References cannot be used in add operations!");
                return Type.NONE;
            }
            case STRING -> {
                return Type.STRING;
            }
            case INT -> {
                return Type.INT;
            }
            default -> {
                System.out.println("Add operation was used on invalid operands!");
                return Type.NONE;
            }
        }
    }

    @Override
    public Type visitReference(TutorialParser.ReferenceContext ctx) {
        String objectId = ctx.ID().getText();
        if (!this.objectIds.contains(objectId)) {
            System.out.println("Referenced object \""+ objectId +"\" did not exist!");
            return Type.NONE;
        }
        return Type.REF;
    }
}
