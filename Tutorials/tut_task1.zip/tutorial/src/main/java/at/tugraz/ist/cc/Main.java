package at.tugraz.ist.cc;

import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        // lexer
        TutorialLexer tutorialLexer = new TutorialLexer(
                CharStreams.fromFileName("src/main/resources/objects.txt")
        );

        // register custom error listener
        tutorialLexer.removeErrorListeners();
        tutorialLexer.addErrorListener(new LexerErrorListener());

        // parser
        TutorialParser tutorialParser = new TutorialParser(new CommonTokenStream(tutorialLexer));

        // register custom error listener
        tutorialParser.removeErrorListeners();
        tutorialParser.addErrorListener(new ParserErrorListener());

        // perform syntax analysis and retrieve parse tree
        ParseTree parseTree = tutorialParser.objects();

        // perform semantic analysis
        SemanticAnalysisVisitor semanticAnalysisVisitor = new SemanticAnalysisVisitor();
        semanticAnalysisVisitor.visit(parseTree);
    }
}